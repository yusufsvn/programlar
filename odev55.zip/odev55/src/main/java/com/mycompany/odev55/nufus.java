/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.odev55;

import java.util.Scanner;

/**
 *
 * @author yusuf
 */
public class nufus {
    public insan insanekle(){
        insan ke = new insan();
        Scanner ad1 = new Scanner(System.in);
        System.out.println("ad:");
        ke.ad=ad1.next();
        System.out.println("soyad:");
        ke.soyad=ad1.next();
        System.out.println("yas:");
        ke.yas=ad1.nextInt();
        System.out.println("boy:");
        ke.boy=ad1.nextInt();
        System.out.println("kilo");
        ke.kilo=ad1.nextInt();
        return ke;
    }


}       
