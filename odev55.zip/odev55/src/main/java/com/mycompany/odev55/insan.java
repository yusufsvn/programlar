
package com.mycompany.odev55;


 
public class insan {
    public String ad;
    public String soyad;
    public int yas;
    public int boy;
    public int kilo;
}
 
    
    
