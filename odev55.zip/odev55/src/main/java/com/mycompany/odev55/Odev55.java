package com.mycompany.odev55;



public class Odev55 {
    static insan[] insanlist = new insan[0];
    
    public static void main(String[] args) {
        System.out.println("kac tane olsun");
        int a =2;
        
        insanlist = new insan[a];
        nufus ak = new nufus();
        for(int i=0; i<a;i++){
            insanlist[i]=ak.insanekle();
            
                    }
       
        }
            
        
}
    
