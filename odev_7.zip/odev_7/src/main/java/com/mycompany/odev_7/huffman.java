/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.odev_7;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author yusuf
 */
public class huffman {
    
    
    public void huffMAN(){
        Scanner input  = new Scanner(System.in);
        String metin = input.nextLine();
        char[] ch=metin.toCharArray();  // string i listeye attı
        System.out.println(Arrays.toString(ch)); // ekranda görebilmemiz ve split etmek için
        System.out.println(ch[5]);   // indexlerine erişebiliyoruz artık
        int countA=0;
        int countB=0;
        int countC=0;
        int countD=0;
        
        for(int i=0;i<ch.length;i++ ){ // bu döngüyle frekans bulduk
            if(ch[i]=='A'){
                countA++;
            }
            if(ch[i]=='B'){
                countB++;
            }
            if(ch[i]=='C'){
                countC++;
            }
            if(ch[i]=='D'){
                countD++;
            }
        }
        
        int[] que = new int[(ch.length)*2-1];
        que[0]=countA;
        que[1]=countB;
        que[2]=countC;
        que[3]=countD;
        this.sort(que);
        
        
        int a1=que[0]+que[1];
        int a2=que[2]+a1;
        int a3= que[3]+a2;
        que[4]=a1;
        que[5]=a2;
        que[6]=a3;
        this.sort(que);
        int[] arr = new int[(ch.length-1)*3];
        
        //düzeltilmeli daha sade olmalı
        arr[0]=que[0];
        arr[1]=que[1];
        arr[2]=que[0]+que[1];
        arr[3]=que[2];
        arr[4]=que[3];
        arr[5]=que[2]+que[3];
        arr[6]=que[4];
        arr[7]=que[5];
        arr[8]=que[4]+que[5];
        
        String sayA = "";
        sayA=funx(arr,sayA,countA);//reverse işlemi yapılmalı
        
        String sayB = "";
        sayB=funx(arr,sayB,countB);
        
        String sayC = "";
        sayC=funx(arr,sayC,countC);
        
        String sayD = "";
        sayD=funx(arr,sayD,countD);
        
        System.out.println(sayA);
        System.out.println(sayB);
        System.out.println(sayC);
        System.out.println(sayD);
        
        
    }
    
    public String funx(int arr[],String A,int aranan){
        for(int i=0;i<arr.length;i++){
            if(arr[i]==aranan && (i%3)!=2){
                String k=Integer.toString(i%3);
                A=A+k;
                int h = 0;
                if(i%3==0){
                    h = 4;
                    
                }
                else if(i%3==1){
                    h = 3;
                }
                for(int j=(i+(i%3)+h);j<arr.length;j++){
                    if(arr[j]==arr[i+(i%3)+1]){
                        String a=Integer.toString(j%3);
                        A=A+a;
                        
                    }
                }
            }
            
        }return A;
        
    }  
    public void sort(int[] arr){
        int n = arr.length;  
        int temp = 0;  
        for(int i=0; i < n; i++){  
            for(int j=1; j < (n-i); j++){  
                if(arr[j-1] > arr[j]){  
                    temp = arr[j-1];  
                    arr[j-1] = arr[j];  
                    arr[j] = temp; 
                }
            }
        }
    }

    
    
    
}
