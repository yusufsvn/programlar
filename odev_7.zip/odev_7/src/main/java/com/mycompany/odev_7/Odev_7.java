/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.odev_7;

/**
 *
 * @author yusuf
 */
public class Odev_7 {

    public static void main(String[] args) {
        huffman a = new huffman();
        a.huffMAN();
        //sadece ABCD harfleri ve hepsi girilmeli
        
    }
}
