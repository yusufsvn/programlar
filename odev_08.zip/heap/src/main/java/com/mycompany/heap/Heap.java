/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.heap;


import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author yusuf
 */
public class Heap {

    public static void main(String[] args) {
        String metin = new Scanner(System.in).nextLine();
        heap1 asd = new heap1();		
	int[] sayilar = new int[asd.x(metin)];
	sayilar = asd.diziOlustur(metin, sayilar);
        asd.minheapmisin(sayilar);
        asd.a(sayilar);
    
    
    }
        
    
}
