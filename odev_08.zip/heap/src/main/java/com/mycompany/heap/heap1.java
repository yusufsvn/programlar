/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.heap;

import static java.lang.Math.round;

/**
 *
 * @author yusuf
 */
public class heap1 {
    public int[] a(int[] arr){
        for(int j=0;j<arr.length;j++){
            for(int i=arr.length-1;i>-1;i--){
                if(arr[round((i-1)/2)-1] > arr[i]){
                    int tmp = arr[round((i-1)/2)-1];
                    arr[round((i-1)/2)-1]=arr[i];
                    arr[i]=tmp;
                }
            }
        }
        return arr;
    }   
    public void minheapmisin(int[] arr){
        boolean count=true;
        for(int i=0;i<arr.length;i++){
            if(arr[i]>arr[(3*i)+1]){
                count=false;
            }
            if(arr[i]>arr[(3*i)+2]){
                count=false;
            }
            if(arr[i]>arr[(3*i)+3]){
                count=false;
            }
        }
        
        if(count==false){
            System.out.println("min heap değildir");
            
        }
        else if(count == true ){
            System.out.println("evet min heap");
        }
    
    }
    
    public int x(String sayilar) {
		int x = 0;
		for (int i = 0; i < sayilar.length(); i++) {
			if (sayilar.substring(i, i + 1).equals(",")) {
				x++;
			}
		}
		x++;
		return x;
	}

    public int[] diziOlustur(String sayilar, int[] arr) {
	int y = 0, a = 0;
	int virgul = 0;
	for (int i = 0; i < sayilar.length(); i++) {
		if (sayilar.substring(i, i + 1).equals(",")) {
			arr[a] = Integer.valueOf(sayilar.substring(y, i));
			a++;
			y = i + 1;
			virgul = i;
		}
	}
	arr[a] = Integer.valueOf(sayilar.substring(virgul + 1, sayilar.length()));
	return arr;
	}
    
    
}
